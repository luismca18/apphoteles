# Google Sheets API

The old demo used a deprecated version of the Google Sheets API to export data
from Google Sheets Documents.

[The new demo](https://docs.sheetjs.com/docs/demos/gsheet) uses
the new Google Sheets API to read and write data.

[![Analytics](https://ga-beacon.appspot.com/UA-36810333-1/SheetJS/js-xlsx?pixel)](https://github.com/SheetJS/js-xlsx)
