# Meteor

This demo originally covered Meteor's package manager and other nuances.  At the
time the demo was written, Meteor had its own ecosystem that clashed with the
burgeoning NodeJS package ecosystem.  Eventually, Meteor added proper support
for NodeJS modules.  New projects should follow the instructions for packages.

[![Analytics](https://ga-beacon.appspot.com/UA-36810333-1/SheetJS/js-xlsx?pixel)](https://github.com/SheetJS/js-xlsx)
