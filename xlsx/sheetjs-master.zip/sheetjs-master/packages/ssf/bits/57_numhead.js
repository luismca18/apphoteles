var write_num/*:SSF_write_num*/ = (function make_write_num(){
