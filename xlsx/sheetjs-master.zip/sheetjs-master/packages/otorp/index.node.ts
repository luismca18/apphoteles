/*! otorp (C) 2013-present SheetJS -- http://sheetjs.com */

import otorp from "./src/otorp";
export { otorp };